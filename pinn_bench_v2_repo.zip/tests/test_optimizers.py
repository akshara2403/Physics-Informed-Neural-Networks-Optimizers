import pytest
import torch

from pinn_bench.optimizers.shampoo import StableShampoo
from pinn_bench.optimizers.soap import SOAP
from pinn_bench.optimizers.muon import Muon, _newton_schulz5
from pinn_bench.optimizers.conflict_averse import conflict_averse_gradients
from pinn_bench.diagnostics import gradient_conflict_cosine


@pytest.mark.parametrize("optimizer_cls,kwargs", [
    (StableShampoo, dict(lr=0.05, update_freq=5)),
    (SOAP, dict(lr=0.01, update_freq=5)),
    (Muon, dict(lr=0.02, adam_lr=0.01)),
])
def test_optimizer_reduces_loss_on_toy_regression(optimizer_cls, kwargs):
    torch.manual_seed(0)
    model = torch.nn.Sequential(
        torch.nn.Linear(4, 16), torch.nn.Tanh(), torch.nn.Linear(16, 1)
    )
    X = torch.randn(64, 4)
    true_W = torch.randn(4, 1)
    y = X @ true_W + 0.01 * torch.randn(64, 1)

    optimizer = optimizer_cls(model.parameters(), **kwargs)
    losses = []
    for _ in range(60):
        optimizer.zero_grad()
        pred = model(X)
        loss = torch.mean((pred - y) ** 2)
        loss.backward()
        optimizer.step()
        losses.append(loss.item())

    assert all(torch.isfinite(torch.tensor(losses)))
    assert losses[-1] < losses[0] * 0.5, f"loss did not decrease enough: {losses[0]} -> {losses[-1]}"


def test_newton_schulz5_bounds_singular_values():
    """The quintic Newton-Schulz map used by Muon does NOT converge to exact
    orthogonality as steps -> infinity -- its scalar map s -> a*s+b*s^3+c*s^5
    has fixed points near 0.87 and 1.26 (not 1) and is chaotic outside a
    narrow basin, which we verified numerically before writing this test
    (running more iterations does not monotonically improve orthogonality).
    Its actual, documented guarantee (Jordan et al. 2024) is that after the
    default 5 steps it keeps singular values within a bounded range of 1,
    which is all Muon's momentum-orthogonalization needs -- so that is what
    this test checks, rather than asserting exact orthonormality.
    """
    torch.manual_seed(0)
    G = torch.randn(8, 5)
    ortho = _newton_schulz5(G, steps=5)
    sing_vals = torch.linalg.svdvals(ortho)
    assert torch.all(sing_vals > 0.3)
    assert torch.all(sing_vals < 2.0)


class _ScalarToy(torch.nn.Module):
    """A single scalar parameter -- lets the exact PCGrad-projection algebra
    in conflict_averse_gradients be checked by hand, not just "it runs"."""
    def __init__(self, init=0.0):
        super().__init__()
        self.w = torch.nn.Parameter(torch.tensor(float(init)))


def test_conflict_averse_cancels_perfectly_opposed_equal_gradients():
    # At w=0: grad(pde_loss) = 2*(w-1) = -2, grad(data_loss) = 2*(w+1) = +2.
    # Equal magnitude, exactly opposite direction -> cosine == -1 exactly,
    # and the symmetric PCGrad-style projection should cancel both fully.
    model = _ScalarToy(init=0.0)
    pde_loss = (model.w - 1.0) ** 2
    data_loss = (model.w + 1.0) ** 2

    params, combined_grads, cosine = conflict_averse_gradients(model, pde_loss, data_loss)
    assert cosine == pytest.approx(-1.0, abs=1e-6)
    assert combined_grads[0].item() == pytest.approx(0.0, abs=1e-6)


def test_conflict_averse_cosine_matches_independent_diagnostic():
    """conflict_averse_gradients computes its own cosine inline (for
    efficiency, so ConflictAverseAdam doesn't need a second pass); it must
    agree with diagnostics.gradient_conflict_cosine, which computes the same
    quantity completely independently. A partial-conflict case (not the
    exactly-opposed toy above) exercises the general path."""
    torch.manual_seed(0)
    model = torch.nn.Sequential(torch.nn.Linear(3, 4), torch.nn.Tanh(), torch.nn.Linear(4, 1))
    X = torch.randn(16, 3)
    pde_loss = torch.mean(model(X) ** 2)
    data_loss = torch.mean((model(X) - 1.0) ** 2)

    cosine_from_diagnostics = gradient_conflict_cosine(model, pde_loss, data_loss)
    _, _, cosine_from_optimizer = conflict_averse_gradients(model, pde_loss, data_loss)
    assert cosine_from_optimizer == pytest.approx(cosine_from_diagnostics, abs=1e-5)


class _VectorToy(torch.nn.Module):
    """Two scalar parameters, constructed so grad(pde_loss) and
    grad(data_loss) are known exactly by hand: a *partial*, not total,
    conflict (unlike the perfectly-opposed scalar case above), which is the
    more typical situation during real training."""
    def __init__(self):
        super().__init__()
        self.w = torch.nn.Parameter(torch.zeros(2))


def test_conflict_averse_projection_resolves_the_conflict():
    """What the symmetric PCGrad-style projection actually guarantees is NOT
    that the combined gradient's norm shrinks (checked this by hand while
    writing the test: it can legitimately grow, since both vectors are
    pushed off the conflicting axis and can add constructively elsewhere --
    e.g. grad_pde=[-2,-2], grad_data=[2,-1] here gives a *larger*-norm
    combined vector, [0.3,-3.9] vs the naive sum's [0,-3]). The property that
    IS provably guaranteed (worked out algebraically: new_g1.new_g2 =
    d*(d^2/(|g1|^2|g2|^2) - 1) >= 0 whenever d = g1.g2 < 0, by
    Cauchy-Schwarz) is that the two *projected* components no longer
    conflict with each other -- that's what this test checks, plus that the
    projection actually changed something relative to the naive sum."""
    model = _VectorToy()
    w = model.w
    # At w=(0,0): grad_pde = [-2,-2], grad_data = [2,-1] -> dot = -2 (< 0,
    # a genuine but partial conflict; worked out by hand before writing this).
    pde_loss = (w[0] - 1.0) ** 2 + (w[1] - 1.0) ** 2
    data_loss = (w[0] + 1.0) ** 2 + 0.1 * (w[1] - 5.0) ** 2

    params = [p for p in model.parameters() if p.requires_grad]
    grad_pde = torch.autograd.grad(pde_loss, params, retain_graph=True)
    grad_data = torch.autograd.grad(data_loss, params, retain_graph=True)
    naive_sum = torch.cat([(a + b).reshape(-1) for a, b in zip(grad_pde, grad_data)])
    flat_pde = torch.cat([g.reshape(-1) for g in grad_pde])
    flat_data = torch.cat([g.reshape(-1) for g in grad_data])
    dot = torch.dot(flat_pde, flat_data)

    proj_pde = flat_pde - (dot / torch.dot(flat_data, flat_data)) * flat_data
    proj_data = flat_data - (dot / torch.dot(flat_pde, flat_pde)) * flat_pde
    post_projection_dot = torch.dot(proj_pde, proj_data).item()

    _, combined_grads, cosine = conflict_averse_gradients(model, pde_loss, data_loss)
    combined_flat = torch.cat([g.reshape(-1) for g in combined_grads])

    assert cosine == pytest.approx(-2.0 / (8.0 ** 0.5 * 5.0 ** 0.5), abs=1e-5)
    assert cosine < 0.0, "test setup should produce conflicting gradients"
    assert post_projection_dot >= -1e-6, "projected components should no longer conflict"
    assert not torch.allclose(combined_flat, naive_sum), "projection should change the update"


def test_conflict_averse_trains_a_real_tiny_pinn_run():
    """End-to-end smoke test through the actual training pipeline (not just
    the projection math in isolation): ConflictAverseAdam should train a real
    PINN for a handful of steps without a non-finite loss or a crash."""
    from pinn_bench.problems import heat
    from pinn_bench.training import train_one_run

    problem = heat.make_data(seed=0, n_f=64, n_ic=16, n_bc=16)
    result, history, y_pred = train_one_run(
        problem, "heat", "ConflictAverseAdam", seed=0,
        steps_cfg={"conflict_averse_steps": 20}, hparams={}, device="cpu",
    )
    assert result["failure_flag"] == "ok"
    assert len(history) > 0
    assert "grad_conflict_cosine" in history.columns
