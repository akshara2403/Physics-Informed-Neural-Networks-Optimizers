"""ConflictAverseAdam -- a new optimizer for this project's v2 extension,
motivated directly by the v1 mechanistic finding (see docs/RESULTS.md,
Section 5): every optimizer except Muon converges to near-total opposition
(cosine -> -1) between the PDE-residual gradient and the IC/BC-data
gradient, and Muon's one clear win (Burgers') coincides with it being the
only optimizer that avoids this conflict.

v1 only *measured* that conflict (gradient_conflict_cosine in diagnostics.py)
and speculated about why Muon avoids it. This optimizer instead acts on the
measurement directly: at every step, it computes grad(L_PDE) and
grad(L_IC+BC) *separately*, and if they are pointing against each other
(cosine < 0), it applies a symmetric gradient-surgery projection -- in the
spirit of PCGrad (Yu et al., 2020, "Gradient Surgery for Multi-Task
Learning") -- to remove the mutually-conflicting component from each before
combining them into the update. When the two gradients already agree
(cosine >= 0) the projection is the identity and this reduces to plain Adam
on the summed gradient, i.e. ConflictAverseAdam only ever intervenes when
there is something to resolve.

This is deliberately a new, independent idea, not a reimplementation of a
published PINN optimizer: PCGrad itself was designed for multi-task
learning with independent tasks sharing a backbone, not for a PDE residual
loss vs. a data loss on a single shared output -- applying it here, and
testing whether it reproduces or exceeds Muon's Burgers' win and closes the
gap on the geometrically "easy" problems where projection is mostly a
no-op, is the actual experiment.

Algorithm, per step:
    g_pde  = zero-filled grad(L_PDE)  w.r.t. all model parameters
    g_data = zero-filled grad(L_IC + L_BC)  w.r.t. all model parameters
    (zero-filling None entries from allow_unused=True is the same fix
    gradient_conflict_cosine required the first time it was run for real --
    see diagnostics.py's docstring)
    dot = <g_pde, g_data>
    if dot < 0:
        g_pde  <- g_pde  - (dot / |g_data|^2) * g_data
        g_data <- g_data - (dot / |g_pde|^2)  * g_pde
    g_combined = g_pde + g_data
    assign g_combined as each parameter's .grad, then take one torch.optim.Adam
    step (Adam's own moment bookkeeping is unmodified -- only the gradient
    fed into it is different from plain Adam's).

What this projection actually guarantees (worked out algebraically and
checked in tests/test_optimizers.py before relying on it): after the
projection, the two *projected* components no longer conflict with each
other -- new_g_pde . new_g_data >= 0 always, whenever the original dot
product was negative. This follows from Cauchy-Schwarz:
new_g1.new_g2 = dot * (dot^2 / (|g1|^2 |g2|^2) - 1), and the bracketed term
is <= 0 whenever |cos| <= 1, so the whole expression is >= 0 when dot < 0.
What it does NOT guarantee is that the combined gradient's norm shrinks --
pushing both vectors off the conflicting axis symmetrically can make them
add constructively in the remaining direction, so |g_combined| can
legitimately end up larger than the naive |g_pde + g_data|. Both of these
were confirmed empirically, not just assumed, while building this module.
"""
import torch


def conflict_averse_gradients(model, pde_loss, data_loss):
    """Compute the projected, conflict-resolved combined gradient.

    Returns (params, combined_grads, cosine) where combined_grads[i] is the
    gradient to assign to params[i].grad before an optimizer.step(), and
    cosine is cos(angle(grad_pde, grad_data)) *before* projection -- the same
    quantity gradient_conflict_cosine measures, so the two can be cross-
    checked against each other (done in tests/test_optimizers.py).
    """
    params = [p for p in model.parameters() if p.requires_grad]
    grad_pde = torch.autograd.grad(pde_loss, params, retain_graph=True, allow_unused=True)
    grad_data = torch.autograd.grad(data_loss, params, retain_graph=True, allow_unused=True)

    g_pde = [g if g is not None else torch.zeros_like(p) for g, p in zip(grad_pde, params)]
    g_data = [g if g is not None else torch.zeros_like(p) for g, p in zip(grad_data, params)]

    flat_pde = torch.cat([g.reshape(-1) for g in g_pde])
    flat_data = torch.cat([g.reshape(-1) for g in g_data])

    dot = torch.dot(flat_pde, flat_data)
    norm_pde_sq = torch.dot(flat_pde, flat_pde)
    norm_data_sq = torch.dot(flat_data, flat_data)

    cosine = 0.0
    denom = (norm_pde_sq.clamp_min(1e-24).sqrt() * norm_data_sq.clamp_min(1e-24).sqrt())
    if denom.item() > 1e-12:
        cosine = (dot / denom).item()

    proj_pde, proj_data = flat_pde, flat_data
    if dot.item() < 0.0:
        if norm_data_sq.item() > 1e-24:
            proj_pde = flat_pde - (dot / norm_data_sq) * flat_data
        if norm_pde_sq.item() > 1e-24:
            proj_data = flat_data - (dot / norm_pde_sq) * flat_pde

    combined_flat = (proj_pde + proj_data).detach()

    combined_grads = []
    idx = 0
    for p in params:
        n = p.numel()
        combined_grads.append(combined_flat[idx:idx + n].reshape(p.shape).clone())
        idx += n

    return params, combined_grads, cosine
