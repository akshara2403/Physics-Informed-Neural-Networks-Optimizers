from . import heat, burgers, allen_cahn, kdv, nls

PROBLEMS = {
    heat.NAME: heat,
    burgers.NAME: burgers,
    allen_cahn.NAME: allen_cahn,
    kdv.NAME: kdv,
    nls.NAME: nls,
}

# The three benchmarks that appear in the original roadmap. KdV and NLS are
# novel additions from this project and are deliberately excluded here so any
# "roadmap vs. novel" comparison in reports stays honest.
ROADMAP_PROBLEMS = (heat.NAME, burgers.NAME, allen_cahn.NAME)
NOVEL_PROBLEMS = (kdv.NAME, nls.NAME)
