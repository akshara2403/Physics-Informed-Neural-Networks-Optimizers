"""Nonlinear Schrodinger (NLS) equation benchmark -- new in this project's v2
extension, against the public reference solution from the original PINNs
repository (Raissi, Perdikaris & Karniadakis 2019), the same repo already
used for the Burgers' benchmark.

    i*h_t + 0.5*h_xx + |h|^2*h = 0,   x in [-5, 5) periodic,  t in [0, pi/2]
    h(x, 0) = 2*sech(x)

h is complex; the model is extended to output two real channels, h = u + i*v,
which makes this the one benchmark in the suite with a vector-valued (not
scalar) solution field. Splitting the PDE into real/imaginary parts gives two
coupled residuals:

    f_u := -v_t + 0.5*u_xx + (u^2 + v^2)*u = 0   (real part)
    f_v :=  u_t + 0.5*v_xx + (u^2 + v^2)*v = 0   (imaginary part)

This is deliberately the "crazier" benchmark added for the v2 experiment: it
is the only problem with a multi-component output, a genuinely nonlinear
|h|^2*h term (in addition to Burgers', which has u*u_x), and periodic rather
than Dirichlet boundary conditions. Unlike KdV (where we generated our own
exact solution), the reference here -- like Burgers' -- comes directly from
the original PINNs paper's own public data file, so boundary values used for
training are the paper's own numerically-verified periodic solution, not an
approximation.
"""
import os
import urllib.request

import numpy as np
import scipy.io

NAME = "nls"

# Same upstream repository as burgers.py's _DATA_URL, different subdirectory
# (this one really is "main/Data/...", found by probing candidate paths
# directly -- the "appendix/Data/..." path burgers.py uses 404s for NLS.mat).
_DATA_URL = (
    "https://raw.githubusercontent.com/maziarraissi/PINNs/master/"
    "main/Data/NLS.mat"
)

# Output layers for this problem: 2 real channels (u, v) instead of 1.
OUTPUT_DIM = 2
LAYERS = (2, 32, 32, 32, 2)


def _download(data_dir):
    os.makedirs(data_dir, exist_ok=True)
    out_path = os.path.join(data_dir, "NLS.mat")
    if not os.path.exists(out_path):
        urllib.request.urlretrieve(_DATA_URL, out_path)
    data = scipy.io.loadmat(out_path)
    for key in ("tt", "x", "uu"):
        if key not in data:
            raise RuntimeError(f"NLS reference data missing key: {key}")
    return out_path


def make_data(seed, n_f=1500, n_ic=150, n_bc=150, data_dir="data", **_):
    rng = np.random.default_rng(seed)
    mat_path = _download(data_dir)
    data = scipy.io.loadmat(mat_path)

    t = data["tt"].flatten()[:, None]
    x = data["x"].flatten()[:, None]
    Exact = data["uu"].T  # complex128, shape (len(t), len(x))

    X, T = np.meshgrid(x, t)
    X_star = np.hstack([X.reshape(-1, 1), T.reshape(-1, 1)])
    u_star = np.real(Exact).reshape(-1, 1)
    v_star = np.imag(Exact).reshape(-1, 1)
    h_star = np.hstack([u_star, v_star])
    lb = X_star.min(axis=0)
    ub = X_star.max(axis=0)

    # Initial condition at t = 0: h(x, 0) = 2*sech(x), taken from the
    # reference grid's first time row (matches it to machine precision --
    # verified while building this benchmark).
    X_ic_all = np.hstack([X[0:1, :].T, T[0:1, :].T])
    h_ic_all = np.hstack([
        np.real(Exact[0:1, :]).T, np.imag(Exact[0:1, :]).T,
    ])
    idx_ic = rng.choice(X_ic_all.shape[0], size=min(n_ic, X_ic_all.shape[0]), replace=False)
    X_ic, y_ic = X_ic_all[idx_ic], h_ic_all[idx_ic]

    # Periodic boundary at x = -5 and x = +5 (the domain's last sampled
    # point before wraparound). We match each side to the reference
    # solution's own value there rather than an interpolated approximation
    # (as Allen-Cahn does) -- the public NLS.mat data already gives a
    # numerically periodic solution at both edges, so simple regression to
    # each side's true value enforces periodicity to the same accuracy the
    # reference solver achieved. Derivative-matching periodicity (u_x, v_x)
    # is NOT separately enforced here -- a stated simplification relative to
    # the original paper's own periodic-BC treatment.
    X_bc_all = np.vstack([
        np.hstack([X[:, 0:1], T[:, 0:1]]),
        np.hstack([X[:, -1:], T[:, -1:]]),
    ])
    y_bc_all = np.vstack([
        np.hstack([np.real(Exact[:, 0:1]), np.imag(Exact[:, 0:1])]),
        np.hstack([np.real(Exact[:, -1:]), np.imag(Exact[:, -1:])]),
    ])
    idx_bc = rng.choice(X_bc_all.shape[0], size=min(n_bc, X_bc_all.shape[0]), replace=False)
    X_bc, y_bc = X_bc_all[idx_bc], y_bc_all[idx_bc]

    X_f = lb + (ub - lb) * rng.random(size=(n_f, 2))
    X_f = np.vstack([X_f, X_ic, X_bc])

    return {
        "name": NAME, "lb": lb, "ub": ub, "layers": LAYERS, "output_dim": OUTPUT_DIM,
        "X_f": X_f, "X_ic": X_ic, "y_ic": y_ic,
        "X_bc": X_bc, "y_bc": y_bc,
        "X_test": X_star, "y_test": h_star,
        "grid_shape": X.shape, "x_grid": x.flatten(), "t_grid": t.flatten(),
    }


def residual(model, X_f, problem, gradients):
    import torch

    h = model(X_f)
    u, v = h[:, 0:1], h[:, 1:2]

    grad_u = gradients(u, X_f)
    u_x, u_t = grad_u[:, 0:1], grad_u[:, 1:2]
    u_xx = gradients(u_x, X_f)[:, 0:1]

    grad_v = gradients(v, X_f)
    v_x, v_t = grad_v[:, 0:1], grad_v[:, 1:2]
    v_xx = gradients(v_x, X_f)[:, 0:1]

    mag_sq = u ** 2 + v ** 2
    f_u = -v_t + 0.5 * u_xx + mag_sq * u
    f_v = u_t + 0.5 * v_xx + mag_sq * v
    return torch.cat([f_u, f_v], dim=1)
