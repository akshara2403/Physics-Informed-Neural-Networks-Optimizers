#!/usr/bin/env python3
"""Matched-loss-value gradient-conflict ablation -- the other upgrade
flagged as future work in v1 (manuscript Section 5.2 / 6): v1 logged
gradient-conflict cosine at matched *step counts* across optimizers, which
leaves a real, stated confound unresolved -- a near-zero cosine might mean
"this optimizer resolved the PDE/data conflict" or it might just mean "this
optimizer hasn't trained far enough yet for the conflict to appear." Those
two explanations are indistinguishable when every optimizer is compared at
the same step index, since optimizers converge at very different rates.

This script instead logs grad_conflict_cosine at matched *total-loss*
values: for each optimizer, it records the cosine at the first training
step where the total loss drops below each of a shared list of thresholds
(e.g. 1e-1, 1e-2, 1e-3, ...). Two optimizers compared at "total_loss just
crossed 1e-2" are at a comparable point of overall convergence regardless
of how many steps it took them to get there, which is the fairer
comparison this ablation is meant to provide.

LBFGS is excluded: its internal strong-Wolfe line search calls the closure
multiple times per outer "step" with intermediate loss values that don't
correspond to accepted iterates, so "the step where loss first crossed a
threshold" is not a well-defined quantity for it the way it is for every
first-order optimizer here. This is a stated scope limitation, not an
oversight.

Usage:
    python scripts/matched_loss_ablation.py --problems heat kdv \
        --optimizers Adam Shampoo SOAP Muon ConflictAverseAdam \
        --seeds 0 1 --out results/matched_loss_ablation.csv
"""
import argparse
import os
import sys

import pandas as pd
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from pinn_bench.autodiff import to_tensor  # noqa: E402
from pinn_bench.diagnostics import gradient_conflict_cosine  # noqa: E402
from pinn_bench.models import PINN  # noqa: E402
from pinn_bench.optimizers import build_first_order_optimizer  # noqa: E402
from pinn_bench.optimizers.conflict_averse import conflict_averse_gradients  # noqa: E402
from pinn_bench.problems import PROBLEMS  # noqa: E402
from pinn_bench.training import compute_losses, make_problem_tensors, set_seed  # noqa: E402

DEFAULT_THRESHOLDS = [1e-1, 3e-2, 1e-2, 3e-3, 1e-3]


def run_matched_loss_tracking(problem, problem_name, optimizer_name, seed, thresholds,
                               max_steps, hparams, device, dtype=torch.float32):
    set_seed(seed)
    layers = problem.get("layers", (2, 32, 32, 32, 1))
    model = PINN(problem["lb"], problem["ub"], layers=layers, dtype=dtype).to(device)
    problem_tensors = make_problem_tensors(problem, device, dtype)
    optimizer_hparams = dict((hparams or {}).get(optimizer_name, {}))
    per_problem = optimizer_hparams.pop("per_problem", {})
    if problem_name in per_problem:
        optimizer_hparams.update(per_problem[problem_name])

    remaining = sorted(thresholds, reverse=True)  # loosest first
    records = []

    def maybe_log(step, total_loss, pde_loss, data_loss):
        while remaining and total_loss.item() <= remaining[0]:
            thr = remaining.pop(0)
            cosine = gradient_conflict_cosine(model, pde_loss, data_loss)
            records.append({
                "problem": problem_name, "optimizer": optimizer_name, "seed": seed,
                "loss_threshold": thr, "step_reached": step,
                "actual_total_loss": total_loss.item(), "grad_conflict_cosine": cosine,
            })

    if optimizer_name == "ConflictAverseAdam":
        params = [p for p in model.parameters() if p.requires_grad]
        adam = torch.optim.Adam(params, lr=optimizer_hparams.get("lr", 1e-3))
        for step in range(max_steps):
            if not remaining:
                break
            adam.zero_grad()
            total_loss, pde_loss, ic_loss, bc_loss, data_loss = compute_losses(
                model, problem_tensors, problem_name
            )
            if not torch.isfinite(total_loss):
                break
            maybe_log(step, total_loss, pde_loss, data_loss)
            combine_params, combined_grads, _ = conflict_averse_gradients(model, pde_loss, data_loss)
            for p, g in zip(combine_params, combined_grads):
                p.grad = g
            adam.step()
    else:
        optimizer = build_first_order_optimizer(optimizer_name, model.parameters(), optimizer_hparams)
        for step in range(max_steps):
            if not remaining:
                break
            optimizer.zero_grad()
            total_loss, pde_loss, ic_loss, bc_loss, data_loss = compute_losses(
                model, problem_tensors, problem_name
            )
            if not torch.isfinite(total_loss):
                break
            maybe_log(step, total_loss, pde_loss, data_loss)
            total_loss.backward()
            optimizer.step()

    # Any thresholds never reached within max_steps are recorded as such,
    # rather than silently missing from the output -- an optimizer that
    # never gets below 1e-2 on a given problem is itself part of the result.
    for thr in remaining:
        records.append({
            "problem": problem_name, "optimizer": optimizer_name, "seed": seed,
            "loss_threshold": thr, "step_reached": None,
            "actual_total_loss": None, "grad_conflict_cosine": None,
        })
    return records


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--problems", nargs="+", default=["heat", "kdv"])
    p.add_argument("--optimizers", nargs="+",
                    default=["Adam", "Shampoo", "SOAP", "Muon", "ConflictAverseAdam"])
    p.add_argument("--seeds", type=int, nargs="+", default=[0, 1])
    p.add_argument("--thresholds", type=float, nargs="+", default=DEFAULT_THRESHOLDS)
    p.add_argument("--max-steps", type=int, default=3000)
    p.add_argument("--n-f", type=int, default=2000)
    p.add_argument("--n-ic", type=int, default=200)
    p.add_argument("--n-bc", type=int, default=200)
    p.add_argument("--device", type=str, default="cpu", choices=["cpu", "cuda"])
    p.add_argument("--out", type=str, default="results/matched_loss_ablation.csv")
    args = p.parse_args(argv)

    all_records = []
    for problem_name in args.problems:
        if problem_name not in PROBLEMS:
            raise ValueError(f"Unknown problem: {problem_name}")
        for seed in args.seeds:
            problem = PROBLEMS[problem_name].make_data(
                seed, n_f=args.n_f, n_ic=args.n_ic, n_bc=args.n_bc, data_dir="data",
            )
            for optimizer_name in args.optimizers:
                print(f"Tracking problem={problem_name} optimizer={optimizer_name} seed={seed}")
                records = run_matched_loss_tracking(
                    problem, problem_name, optimizer_name, seed, args.thresholds,
                    args.max_steps, hparams={}, device=args.device,
                )
                all_records.extend(records)

    df = pd.DataFrame(all_records)
    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    df.to_csv(args.out, index=False)
    print("\nWrote:", args.out)
    print(df.groupby(["problem", "optimizer", "loss_threshold"])["grad_conflict_cosine"]
          .mean().to_string())


if __name__ == "__main__":
    main()
