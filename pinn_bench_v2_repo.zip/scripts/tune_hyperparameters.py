#!/usr/bin/env python3
"""Lightweight per-optimizer, per-problem learning-rate tuning -- the
"stronger statistics" upgrade flagged as future work in v1's Limitations
section (manuscript Section 6: "Muon's learning rate is not independently
tuned per problem... a fully rigorous comparison would tune every
optimizer's hyperparameters per problem under an equal tuning budget").

Design choices, stated explicitly:

  * Tuning uses TUNING_SEEDS, which are disjoint from the seeds used in the
    final evaluation sweep (configs/full_v2.yaml uses 0-9; tuning uses
    100-101). This avoids the classic mistake of picking hyperparameters
    using the same seeds the final results are reported on, which would
    silently inflate every tuned optimizer's apparent performance.
  * Tuning runs at a reduced step budget (TUNE_STEP_FRACTION of the full
    config) purely for speed -- the *ranking* of learning rates for a given
    optimizer/problem is assumed to be reasonably stable across budgets,
    which is a real assumption, not a proven fact, and is stated as such.
  * The grid is small and hand-picked per optimizer around its existing
    default (see configs/full_v2.yaml), not an exhaustive search -- this is
    a meaningful rigor upgrade over "one fixed value for every problem", not
    a claim of finding the global-optimal learning rate.
  * LBFGS and Adam_LBFGS's LBFGS phase are not tuned here (LBFGS's own
    line search already adapts its step size; Adam_LBFGS's Adam-pretrain
    learning rate could be tuned the same way as plain Adam if desired, but
    is left at its default to keep this script's scope bounded).

Usage:
    python scripts/tune_hyperparameters.py --base-config configs/full_v2.yaml \
        --out configs/full_v2_tuned.yaml

The output config is a COPY of the base config with only `hparams` replaced
-- the base config (fixed hyperparameters across problems, isolating each
optimizer's built-in inductive bias, exactly as v1's methodology describes)
is left untouched. Running the tuned config is then a genuinely separate,
complementary experiment: "best each optimizer can do with per-problem
tuning" rather than "each optimizer's behavior with one fixed setting."
"""
import argparse
import copy
import os
import sys

import numpy as np
import yaml

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from pinn_bench.config import load_config  # noqa: E402
from pinn_bench.problems import PROBLEMS  # noqa: E402
from pinn_bench.training import train_one_run  # noqa: E402

TUNING_SEEDS = [100, 101]
TUNE_STEP_FRACTION = 0.3

LR_GRID = {
    "Adam": [3e-4, 1e-3, 3e-3],
    "Shampoo": [3e-3, 1e-2, 3e-2],
    "SOAP": [1e-3, 3e-3, 1e-2],
    "Muon": [5e-3, 1e-2, 2e-2],
    "ConflictAverseAdam": [3e-4, 1e-3, 3e-3],
}


def _scaled_steps_cfg(cfg):
    steps = cfg.steps_cfg
    return {k: max(10, int(v * TUNE_STEP_FRACTION)) for k, v in steps.items()}


def tune(cfg, problems, optimizers, device="cpu"):
    tuned_hparams = copy.deepcopy(cfg.hparams or {})
    steps_cfg = _scaled_steps_cfg(cfg)

    for problem_name in problems:
        if problem_name not in PROBLEMS:
            raise ValueError(f"Unknown problem: {problem_name}")
        for optimizer_name in optimizers:
            if optimizer_name not in LR_GRID:
                continue
            best_lr, best_gap = None, float("inf")
            for lr in LR_GRID[optimizer_name]:
                gaps = []
                for seed in TUNING_SEEDS:
                    problem = PROBLEMS[problem_name].make_data(
                        seed, data_dir="data", **cfg.problem_kwargs()
                    )
                    result, _, _ = train_one_run(
                        problem, problem_name, optimizer_name, seed,
                        steps_cfg, {optimizer_name: {"lr": lr}}, device,
                    )
                    gaps.append(result["relative_solution_gap"])
                mean_gap = float(np.nanmean(gaps))
                print(f"  tuning {problem_name}/{optimizer_name}: lr={lr:g} -> "
                      f"mean_gap(tuning seeds)={mean_gap:.4g}")
                if np.isfinite(mean_gap) and mean_gap < best_gap:
                    best_gap, best_lr = mean_gap, lr

            if best_lr is None:
                continue
            tuned_hparams.setdefault(optimizer_name, {})
            tuned_hparams[optimizer_name].setdefault("per_problem", {})
            existing = tuned_hparams[optimizer_name].get("per_problem", {}).get(problem_name, {})
            tuned_hparams[optimizer_name]["per_problem"][problem_name] = {**existing, "lr": best_lr}
            print(f"  -> chosen lr for {problem_name}/{optimizer_name}: {best_lr:g} "
                  f"(mean tuning-seed gap {best_gap:.4g})")

    return tuned_hparams


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--base-config", type=str, required=True)
    p.add_argument("--out", type=str, required=True)
    p.add_argument("--device", type=str, default="cpu", choices=["cpu", "cuda"])
    args = p.parse_args(argv)

    cfg = load_config(args.base_config)
    tuned_hparams = tune(cfg, cfg.problems, cfg.optimizers, device=args.device)

    with open(args.base_config) as f:
        raw = yaml.safe_load(f)
    raw["hparams"] = tuned_hparams
    raw["results_dir"] = raw.get("results_dir", "results/full_v2").rstrip("/") + "_tuned"

    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    with open(args.out, "w") as f:
        yaml.safe_dump(raw, f, sort_keys=False)
    print("\nWrote tuned config to:", args.out)


if __name__ == "__main__":
    main()
