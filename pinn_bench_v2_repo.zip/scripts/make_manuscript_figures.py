#!/usr/bin/env python3
"""Composite, publication-quality figures for the manuscript, built directly
from the actual run's CSVs (results/full/csv/) rather than reusing the raw
per-run diagnostic PNGs. Categorical colors follow the validated dataviz
palette, fixed hue order across all figures (never re-ordered per chart).
"""
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

RESULTS = "/home/claude/pinn_bench/results/full"
OUT = "/home/claude/manuscript_figures"
os.makedirs(OUT, exist_ok=True)

PROBLEMS = ["heat", "burgers", "allen_cahn", "kdv"]
PROBLEM_TITLES = {
    "heat": "Heat (1D, linear)",
    "burgers": "Burgers' (nonlinear advection)",
    "allen_cahn": "Allen-Cahn (stiff)",
    "kdv": "KdV (3rd-order, novel)",
}
OPTIMIZERS = ["Adam", "LBFGS", "Adam_LBFGS", "Shampoo", "SOAP", "Muon"]
OPT_LABELS = {"Adam": "Adam", "LBFGS": "L-BFGS", "Adam_LBFGS": "Adam+L-BFGS",
              "Shampoo": "Shampoo", "SOAP": "SOAP", "Muon": "Muon"}

# Fixed categorical hue order (dataviz skill default palette, light mode),
# assigned by entity (optimizer identity), never re-ordered per chart.
COLORS = {
    "Adam": "#2a78d6",        # slot 1 blue
    "LBFGS": "#eb6834",       # slot 2 orange
    "Adam_LBFGS": "#1baf7a",  # slot 3 aqua
    "Shampoo": "#eda100",     # slot 4 yellow
    "SOAP": "#e87ba4",        # slot 5 magenta
    "Muon": "#008300",        # slot 6 green
}

plt.rcParams.update({
    "font.size": 9,
    "axes.titlesize": 10,
    "axes.labelsize": 9,
    "legend.fontsize": 7.5,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "axes.edgecolor": "#52514e",
    "axes.labelcolor": "#0b0b0b",
    "text.color": "#0b0b0b",
    "xtick.color": "#52514e",
    "ytick.color": "#52514e",
    "axes.grid": True,
    "grid.color": "#e3e2dd",
    "grid.linewidth": 0.6,
    "figure.facecolor": "white",
    "axes.facecolor": "white",
})

all_runs = pd.read_csv(f"{RESULTS}/csv/all_runs.csv")


def fig1_gap_boxplots():
    fig, axes = plt.subplots(2, 2, figsize=(7.2, 5.6))
    for ax, problem in zip(axes.flat, PROBLEMS):
        dfp = all_runs[all_runs["problem"] == problem]
        data = [dfp[dfp["optimizer"] == o]["relative_solution_gap"].values for o in OPTIMIZERS]
        bp = ax.boxplot(data, labels=[OPT_LABELS[o] for o in OPTIMIZERS], patch_artist=True,
                         widths=0.55, showfliers=True,
                         medianprops=dict(color="#0b0b0b", linewidth=1.3),
                         flierprops=dict(marker="o", markersize=3, markerfacecolor="#52514e",
                                          markeredgecolor="none"))
        for patch, o in zip(bp["boxes"], OPTIMIZERS):
            patch.set_facecolor(COLORS[o])
            patch.set_alpha(0.75)
            patch.set_edgecolor("#0b0b0b")
            patch.set_linewidth(0.8)
        ax.set_title(PROBLEM_TITLES[problem])
        ax.set_ylabel("Relative solution gap")
        if problem in ("allen_cahn",):
            pass
        else:
            ax.set_yscale("log")
        ax.tick_params(axis="x", rotation=30)
    fig.suptitle("Relative solution gap by optimizer, across 5 seeds", y=1.01, fontsize=11)
    fig.tight_layout()
    fig.savefig(f"{OUT}/fig1_gap_boxplots.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def fig2_gradient_conflict():
    fig, axes = plt.subplots(2, 2, figsize=(7.2, 5.6))
    for ax, problem in zip(axes.flat, PROBLEMS):
        for o in OPTIMIZERS:
            path = f"{RESULTS}/csv/history_{problem}_{o}_seed0.csv"
            if not os.path.exists(path):
                continue
            hist = pd.read_csv(path).dropna(subset=["grad_conflict_cosine"])
            if len(hist) == 0:
                continue
            ax.plot(hist["step"], hist["grad_conflict_cosine"], color=COLORS[o],
                     linewidth=1.6, marker="o", markersize=2.5, label=OPT_LABELS[o])
        ax.axhline(0.0, color="#8a8880", linewidth=0.8, linestyle="--")
        ax.set_ylim(-1.15, 1.15)
        ax.set_title(PROBLEM_TITLES[problem])
        ax.set_xlabel("Training step (seed 0)")
        ax.set_ylabel("cos(grad PDE, grad IC+BC)")
    handles, labels = axes.flat[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=6, bbox_to_anchor=(0.5, -0.04),
               frameon=False)
    fig.suptitle("Gradient-conflict cosine over training (new diagnostic)", y=1.01, fontsize=11)
    fig.tight_layout(rect=[0, 0.03, 1, 1])
    fig.savefig(f"{OUT}/fig2_gradient_conflict.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def fig3_curvature_vs_difficulty():
    rows = []
    for problem in PROBLEMS:
        for o in OPTIMIZERS:
            path = f"{RESULTS}/csv/history_{problem}_{o}_seed0.csv"
            for seed in range(5):
                p2 = f"{RESULTS}/csv/history_{problem}_{o}_seed{seed}.csv"
                if not os.path.exists(p2):
                    continue
                hist = pd.read_csv(p2).dropna(subset=["hutchinson_trace"])
                if len(hist) == 0:
                    continue
                rows.append({"problem": problem, "optimizer": o, "seed": seed,
                             "mean_abs_hutchinson": hist["hutchinson_trace"].abs().mean()})
    diag = pd.DataFrame(rows)
    curv_by_problem = diag.groupby("problem")["mean_abs_hutchinson"].mean().reindex(PROBLEMS)
    gap_by_problem = all_runs[all_runs["optimizer"] != "Muon"].groupby("problem")["relative_solution_gap"].mean().reindex(PROBLEMS)

    # Two single-axis panels (never a dual-axis/twinx chart on one plot: the
    # two quantities have unrelated units, so a shared axis would imply a
    # false direct comparison).
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.2, 3.2))
    x = range(len(PROBLEMS))
    labels = [PROBLEM_TITLES[p].split(" (")[0] for p in PROBLEMS]

    ax1.bar(x, curv_by_problem.values, width=0.55, color="#4a3aa7", alpha=0.85,
             edgecolor="#0b0b0b", linewidth=0.6)
    ax1.set_ylabel("Mean |Hutchinson trace|\n(curvature proxy)")
    ax1.set_yscale("log")
    ax1.set_xticks(list(x))
    ax1.set_xticklabels(labels, rotation=20, ha="right")
    ax1.set_title("(a) Measured loss curvature")

    ax2.bar(x, gap_by_problem.values, width=0.55, color="#eb6834", alpha=0.85,
             edgecolor="#0b0b0b", linewidth=0.6)
    ax2.set_ylabel("Mean relative solution gap\n(non-Muon optimizers)")
    ax2.set_yscale("log")
    ax2.set_xticks(list(x))
    ax2.set_xticklabels(labels, rotation=20, ha="right")
    ax2.set_title("(b) Mean solution gap")

    fig.suptitle("Measured loss curvature tracks cross-problem difficulty", y=1.03)
    fig.tight_layout()
    fig.savefig(f"{OUT}/fig3_curvature_vs_difficulty.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def fig4_burgers_case_study():
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.0))
    problem = "burgers"

    ax = axes[0]
    for o in OPTIMIZERS:
        path = f"{RESULTS}/csv/history_{problem}_{o}_seed0.csv"
        hist = pd.read_csv(path)
        ax.plot(range(len(hist)), hist["total_loss"], color=COLORS[o], linewidth=1.6,
                label=OPT_LABELS[o])
    ax.set_yscale("log")
    ax.set_xlabel("Logged step index (seed 0)")
    ax.set_ylabel("Total loss (log scale)")
    ax.set_title("(a) Burgers' training loss")

    ax = axes[1]
    dfp = all_runs[all_runs["problem"] == problem]
    means = [dfp[dfp["optimizer"] == o]["relative_solution_gap"].mean() for o in OPTIMIZERS]
    stds = [dfp[dfp["optimizer"] == o]["relative_solution_gap"].std() for o in OPTIMIZERS]
    bar_colors = [COLORS[o] for o in OPTIMIZERS]
    ax.bar(range(len(OPTIMIZERS)), means, yerr=stds, capsize=3, color=bar_colors, alpha=0.85,
           edgecolor="#0b0b0b", linewidth=0.6)
    ax.set_xticks(range(len(OPTIMIZERS)))
    ax.set_xticklabels([OPT_LABELS[o] for o in OPTIMIZERS], rotation=30, ha="right")
    ax.set_ylabel("Mean relative solution gap (+/- 1 std, 5 seeds)")
    ax.set_title("(b) Burgers' final accuracy")

    fig.suptitle("Burgers' equation: the one benchmark where a preconditioned optimizer wins", y=1.04)
    fig.tight_layout()
    fig.savefig(f"{OUT}/fig4_burgers_case_study.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    fig1_gap_boxplots()
    fig2_gradient_conflict()
    fig3_curvature_vs_difficulty()
    fig4_burgers_case_study()
    print("Wrote figures to", OUT)
    for f in sorted(os.listdir(OUT)):
        print(" ", f)
